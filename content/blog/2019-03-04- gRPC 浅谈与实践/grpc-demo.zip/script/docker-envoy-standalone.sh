#!/usr/bin/env bash

set -e

containerName=grpc_envoy_standalone

if [  "$(docker ps -q -f name=grpc_envoy_standalone)" ]; then
    docker container rm $containerName -f
fi


docker build -t grpc_envoy_standalone -f ./Dockerfile-envoy-standalone .

docker run -d -p 9090:9090 -p 9091:9091 --name $containerName grpc_envoy_standalone