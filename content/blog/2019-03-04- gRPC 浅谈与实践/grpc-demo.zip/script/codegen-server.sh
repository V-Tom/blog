#!/usr/bin/env bash

set -e

proto=$1

if [ -z "$proto" ];then
    echo "please prompt at last one argument for input file"
    exit
fi

# server
rm -rf ./server/protobuf-spec && mkdir ./server/protobuf-spec

protoc --go_out=plugins=grpc:./server ./protobuf-spec/$proto.proto

echo "generate server code success with ./server/protobuf-spec/$proto.pb.go"
