#!/usr/bin/env bash

set -e

cd ../web

npx webpack-dev-server --config ./webpack.config.js --watch --port 8081