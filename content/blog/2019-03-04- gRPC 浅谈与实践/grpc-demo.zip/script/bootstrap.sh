#!/usr/bin/env bash


set -e

go get -u google.golang.org/grpc

cd ../web

npm i -d --registry=https://registry.npm.taobao.org

