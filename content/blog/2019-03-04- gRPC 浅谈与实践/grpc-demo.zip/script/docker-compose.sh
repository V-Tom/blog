#!/usr/bin/env bash

set -e

cd $(dirname $0)/..

docker network create grpc

docker-compose pull

docker-compose up --build