#!/usr/bin/env bash

set -e

proto=$1

if [ -z "$proto" ];then
    echo "please prompt at last one argument for input file"
    exit
fi

# web
rm -rf ./web/protobuf && mkdir ./web/protobuf

OUT_DIR=./web/protoc-spec

protoc -I=./protobuf-spec $proto.proto \
    --js_out=import_style=commonjs:$OUT_DIR \
    --grpc-web_out=import_style=commonjs,mode=grpcwebtext:$OUT_DIR

echo "generate client success in directory : $OUT_DIR"
