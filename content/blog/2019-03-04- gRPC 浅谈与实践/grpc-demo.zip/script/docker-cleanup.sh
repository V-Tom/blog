#!/usr/bin/env bash

set -e

docker rmi $(docker images --filter "dangling=true" -q --no-trunc) 2>/dev/null

docker rm $(docker ps -a -f status=exited -q)
