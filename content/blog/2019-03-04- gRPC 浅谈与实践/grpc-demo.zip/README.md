

### grpc-web

初始化请看 [Code Generator](https://github.com/grpc/grpc-web#code-generator-plugin)

[Rebuilding the generated code](https://github.com/grpc/grpc-go/tree/master/examples)

[grpc-web-example](https://github.com/grpc/grpc-web/tree/master/net/grpc/gateway/examples/helloworld)

docker rmi NONE tag images

```bash

docker rmi $(docker images --filter "dangling=true" -q --no-trunc) 2>/dev/null

```

docker rm Exited container

```bash

docker rm $(docker ps -a -f status=exited -q)

```

generator js client code 

```bash

rm -rf ./web/protobuf && mkdir ./web/protobuf && OUT_DIR=./web/protobuf && protoc -I=./protobuf-spec user.proto \
--js_out=import_style=commonjs:$OUT_DIR \
--grpc-web_out=import_style=commonjs,mode=grpcwebtext:$OUT_DIR

```

generator go server code 

```bash
# ./server/user/user.pb.go
rm -rf ./server/protobuf-spec && mkdir ./server/protobuf-spec && protoc --go_out=plugins=grpc:./server ./protobuf-spec/helloworld.proto
```


build envoy standalone

```bash

docker build -t grpc_envoy_standalone -f ./Dockerfile-envoy-standalone .

docker run -p 9090:9090 -p 9091:9091 --network=bridge grpc_envoy_standalone

```

