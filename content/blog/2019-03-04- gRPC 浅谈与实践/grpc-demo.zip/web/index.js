const {HelloRequest} = require('./protobuf/helloworld_pb');
const {GreeterClient} = require('./protobuf/helloworld_grpc_web_pb');

const client = new GreeterClient('http://localhost:9090');

const request = new HelloRequest();
request.setName('gRPC World');

client.sayHello(request, {}, (err, response) => {
    if (err) throw err;
    console.log(response.getMessage());
});